
document.addEventListener('DOMContentLoaded', () => {
  const video = document.getElementById('video');
  const placeholder = document.getElementById('cameraPlaceholder');
  const status = document.getElementById('cameraStatus');
  const dot = document.getElementById('statusDot');
  const start = document.getElementById('startBtn');
  const stop = document.getElementById('stopBtn');
  const prediction = document.getElementById('prediction');
  const confidence = document.getElementById('confidence');
  const bar = document.getElementById('confidenceBar');
  const hint = document.getElementById('resultHint');
  const session = document.getElementById('sessionText');
  const count = document.getElementById('sessionCount');
  const clearBtn = document.getElementById('clearBtn');
  const copyBtn = document.getElementById('copyBtn');

  let stream = null;
  let items = [];
  let timer = null;
  let busy = false;
  let active = false;

  // Prediction stabilization
  let candidateLabel = '';
  let candidateCount = 0;
  let lastAcceptedLabel = '';
  let lastAcceptedTime = 0;
  let noHandCount = 0;

  const REQUIRED_FRAMES = 5;
  const CONFIDENCE_THRESHOLD = 0.75;
  const SAME_SIGN_COOLDOWN = 1200;
  const NO_HAND_RESET_FRAMES = 3;

  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d');

  function setStatus(text, on) {
    status.textContent = text;
    dot.style.background = on ? '#71a88c' : '#c58a61';
  }

  function render() {
    session.textContent = items.length
      ? items.join(' ')
      : 'Your recognized signs will appear here.';

    count.textContent =
      items.length + ' sign' + (items.length === 1 ? '' : 's');
  }

  function resetCandidate() {
    candidateLabel = '';
    candidateCount = 0;
  }

  function resetRecognition() {
    resetCandidate();
    lastAcceptedLabel = '';
    lastAcceptedTime = 0;
    noHandCount = 0;
  }

  async function predictFrame() {
    if (!active || busy || !video.videoWidth || !video.videoHeight) {
      return;
    }

    busy = true;

    try {
      canvas.width = 640;
      canvas.height = Math.round(
        640 * video.videoHeight / video.videoWidth
      );

      context.drawImage(video, 0, 0, canvas.width, canvas.height);

      const response = await fetch('/api/predict', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          image: canvas.toDataURL('image/jpeg', 0.8)
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Prediction request failed');
      }

      if (!active) return;

      if (!data.hand_detected) {
        noHandCount++;
        resetCandidate();

        hint.textContent = 'Show one hand clearly inside the camera frame.';

        if (noHandCount >= NO_HAND_RESET_FRAMES) {
          lastAcceptedLabel = '';
          lastAcceptedTime = 0;
          prediction.textContent = '—';
          confidence.textContent = '—';
          bar.style.width = '0%';
        }

        return;
      }

      noHandCount = 0;

      const label = data.prediction;
      const score = Number(data.confidence);

      if (typeof label !== 'string' || !Number.isFinite(score)) {
        throw new Error('Invalid prediction response');
      }

      if (score < CONFIDENCE_THRESHOLD) {
        resetCandidate();
        hint.textContent = 'Low confidence. Adjust your hand and try again.';
        return;
      }

      // Require five consecutive predictions of the same sign.
      if (label === candidateLabel) {
        candidateCount++;
      } else {
        candidateLabel = label;
        candidateCount = 1;
      }

      hint.textContent =
        `Checking sign ${label}: ${candidateCount}/${REQUIRED_FRAMES}`;

      if (candidateCount < REQUIRED_FRAMES) {
        return;
      }

      // Show only stabilized predictions.
      prediction.textContent = label;
      confidence.textContent = Math.round(score * 100) + '%';
      bar.style.width = Math.round(score * 100) + '%';
      hint.textContent = 'Stable sign detected.';

      const now = Date.now();

      // Add a sign once, not repeatedly while it is held.
      if (label !== lastAcceptedLabel) {
        if (now - lastAcceptedTime >= SAME_SIGN_COOLDOWN) {
          items.push(label);
          render();

          lastAcceptedLabel = label;
          lastAcceptedTime = now;
        }
      }

      // Keep the candidate count capped while the gesture is held.
      candidateCount = REQUIRED_FRAMES;

    } catch (error) {
      if (active) {
        hint.textContent = 'Prediction error: ' + error.message;
      }
    } finally {
      busy = false;
    }
  }

  start.addEventListener('click', async () => {
    if (active) return;

    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'user',
          width: { ideal: 640 },
          height: { ideal: 480 }
        },
        audio: false
      });

      video.srcObject = stream;
      await video.play();

      video.style.display = 'block';
      placeholder.style.display = 'none';
      start.disabled = true;
      stop.disabled = false;

      active = true;
      resetRecognition();

      setStatus('Camera active', true);
      hint.textContent = 'Show a hand sign to begin recognition.';

      timer = setInterval(predictFrame, 500);

    } catch (error) {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }

      stream = null;
      active = false;

      setStatus('Camera unavailable', false);

      hint.textContent = error.name === 'NotAllowedError'
        ? 'Camera permission denied. Allow camera access in browser settings.'
        : 'Could not access the camera: ' + error.message;
    }
  });

  function end() {
    active = false;

    if (timer) {
      clearInterval(timer);
    }

    timer = null;

    if (stream) {
      stream.getTracks().forEach(track => track.stop());
    }

    stream = null;
    video.srcObject = null;
    video.style.display = 'none';
    placeholder.style.display = 'flex';

    start.disabled = false;
    stop.disabled = true;

    setStatus('Camera is off', false);

    prediction.textContent = '—';
    confidence.textContent = '—';
    bar.style.width = '0%';

    hint.textContent = 'Session ended. Start again whenever you are ready.';

    resetRecognition();
  }

  stop.addEventListener('click', end);

  clearBtn.addEventListener('click', () => {
    items = [];
    render();

    // Allow the current gesture to be recognized again after clearing.
    resetRecognition();
  });

  copyBtn.addEventListener('click', async () => {
    if (!items.length) {
      hint.textContent = 'There are no signs to copy yet.';
      return;
    }

    try {
      await navigator.clipboard.writeText(items.join(' '));
      hint.textContent = 'Session text copied.';
    } catch {
      hint.textContent = 'Copy is not available in this browser.';
    }
  });

  render();

  window.SANKET = {
    showPrediction(label, score) {
      prediction.textContent = label;
      confidence.textContent = Math.round(score * 100) + '%';
      bar.style.width = Math.round(score * 100) + '%';
    },
    endSession: end
  };
});

