SANKET FRONTEND STARTER

Contents: Flask-style templates/ and static/ folders.

QUICK SETUP
1. Copy the templates and static folders into your existing Flask project root.
2. Ensure your Flask app serves the templates using render_template. Suggested routes:
   @app.route('/')
   def home(): return render_template('index.html')
   @app.route('/live')
   def live(): return render_template('live.html')
   @app.route('/library')
   def library(): return render_template('library.html')
   @app.route('/sign-detail')
   def sign_detail(): return render_template('sign-detail.html')
   @app.route('/about')
   def about(): return render_template('about.html')
3. For Flask rendering, change page links from *.html to the routes above, or configure static serving for direct HTML previews.
4. The CSS currently links assets with ../static/css/style.css and scripts with ../static/js/*.js, suitable for templates rendered at root routes in typical Flask apps only if adjusted to Flask's url_for. Recommended in each template: href="{{ url_for('static', filename='css/style.css') }}" and script src="{{ url_for('static', filename='js/main.js') }}" (likewise live.js/library.js).
5. Camera access requires localhost or HTTPS. Open the site through Flask on http://127.0.0.1:5000, not as a file.

IMPORTANT
- This is a frontend starter. Camera permission and local session UI work in-browser.
- Real model predictions are NOT connected yet. In live.js, window.SANKET.showPrediction(label, score) is the frontend hook for your backend response. Replace the marked integration comment with frame capture and fetch() to your actual Flask endpoint and call this hook with the returned label and confidence.
- Library signs, symbols, meanings and instructions are placeholders, not verified ISL teaching material. Replace with your validated dataset/content.
- No permanent storage of recognition text is implemented; it is held in page memory and cleared on Stop.
- Google Fonts are imported from an external source; provide local fonts if offline use is required.
